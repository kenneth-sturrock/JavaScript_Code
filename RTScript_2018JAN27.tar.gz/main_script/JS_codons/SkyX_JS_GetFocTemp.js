/* Java Script */
/* Socket Start Packet */

//	
//	Get the focuser temperature	
//
//	Ken Sturrock 
//	January 13, 2018
//

ccdsoftCamera.focTemperature.toFixed(1);

/* Socket End Packet */
