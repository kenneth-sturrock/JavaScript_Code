/* Java Script */
/* Socket Start Packet */

//	
//	This script reports basic statistics after each image - focuser data, filter color and a really crude FWHM measure.
//	It is meant for rough quality tracking via the text output.
//
//	There's some mnonsense in here to deal with an older ZWO camera driver that failed to set all of the required
//	FITs header values. The problem was fixed, but this remains as a fail-safe for the future.	
//
//	Colin McGill also tweaked the code to make it run more efficiently.
//
//	Ken Sturrock 
//	January 19, 2018
//

var FITSProblem = "no";
var units = "pix";
var InvStatus = "Success";
var teleFL = 0;


ccdsoftCameraImage.AttachToActiveImager();


try
{
	ccdsoftCameraImage.FITSKeyword("XPIXSZ")
}
	catch (repErr)
	//
	//	If error, report it. 	
	// 
	{

		if ( ccdsoftCamera.ImageUseDigitizedSkySurvey != 1 ) 		
		{
			FITSProblem = "yes";
		}
	} 


		


try
{
	ccdsoftCameraImage.FITSKeyword("XBINNING")
}
	catch (repErr)
	//
	//	If error, report it. 	
	// 
	{
		FITSProblem = "yes";
	} 


if ( FITSProblem == "no" )
//
// If we can get the header data to calculate the image scale, 
// ask for the OTA Focal Length.
//
{
	teleFL = ccdsoftCamera.PropDbl("m_dTeleFocalLength");
}


try
//
// Try show inventory
//
{ 
	ccdsoftCameraImage.ShowInventory();
}

	catch (repErr)
	//
	// Once again, we're going to use our throw away variable repErr to
	// swallow the actual error message and substitute it for a generic
	// failure message.
	// 
	{
			InvStatus = "Failed";
	}

if ( InvStatus !== "Failed" )
//
// Do the right thing if this works.
//
{
	var FWHM = ccdsoftCameraImage.InventoryArray(4);
	var selectedFWHM = new Array();
	var filter="None";
	var focTemp=0;
	var focPos="None";
	var quality="Nothing";
    	var path="Nothing";

    	// Variables to hold median and max values.
	//
	// Thanks to Colin McGill for this modification, which dramatically speeds up processing.
	//
	//				http://www.bisque.com/sc/forums/p/31318/158417.aspx#158417
	//
    	var medFWHM = median(FWHM);
    	var maxFWHM = Math.max.apply(Math, FWHM);

	function median(values)
	//
	// Calculate the median value of an array.
	//
	// Stolen from code by caseyjustus and mviktora at the URL: 
	//
	//				https://gist.github.com/caseyjustus/1166258
	//
	{
		values.sort( function(a,b) {return a - b;} );
		var half = Math.floor(values.length/2);

		if(values.length % 2)
		{
			return values[half];
		} else {
    	 		return (values[half-1] + values[half]) / 2.0; 
		}
	}

	for (ls = 0; ls < FWHM.length; ++ls)

		if ((FWHM[ls] > medFWHM) && (FWHM[ls] < maxFWHM))
		//
		// This is a filter that tries to generate a more meaningful FWHM
		//
		{
			selectedFWHM.push(FWHM[ls]);
		}

	if ( SelectedHardware.focuserModel !== "<No Focuser Selected>" )
	//
	// This test looks to see if there is a focuser. If not, return "No Focuser".
	// Otherwise, run @Focus2.
	//
	{
		focTemp = ccdsoftCamera.focTemperature.toFixed(1);
		focPos = ccdsoftCamera.focPosition;
	}

	if ( SelectedHardware.filterWheelModel !== "<No Filter Wheel Selected>" )
	//
	// This test looks to see if there is a filter wheel. If not, return "NA".
	// Otherwise, give us the filter name for the main script's pretty printing.
	//
	{
		filter=ccdsoftCamera.szFilterName(ccdsoftCamera.FilterIndexZeroBased);	
	} 

	quality = median(selectedFWHM);
	path = ccdsoftCameraImage.Path;	

	if ( teleFL !== 0 )
	{

		units = "AS"

		if ( ccdsoftCamera.ImageUseDigitizedSkySurvey == "1" ) 
		//
		//	Imaging Camera Voodoo
		//
		//	The DSS images don't have a FITS keyword for focal length so
		//	just set the image scale without doing the math.
		//
		{
		
			var camImageScale = 1.70;
			quality = quality * camImageScale; 
		
		} else {
		
			var camFocalLength = ccdsoftCameraImage.FITSKeyword ("FOCALLEN");
			var camPixelSize = ccdsoftCameraImage.FITSKeyword ("XPIXSZ");
			var camBinning = ccdsoftCameraImage.FITSKeyword ("XBINNING");
	
			var camImageScale = ( (camPixelSize * camBinning) / camFocalLength ) * 206.3;
			
			quality = quality * camImageScale; 
		}
	}	

	out = "Stats: Filter=" + filter + ", Temp=" + focTemp + ", FocPos=" + focPos + ", FWHM(" + units + ")=" + quality.toFixed(2) + "; " + path;
	
} else {

	var filter="None";
	var focTemp=0;
	var focPos="None";
	var path = ccdsoftCameraImage.Path;	

	if ( SelectedHardware.focuserModel !== "<No Focuser Selected>" )
	//
	// This test looks to see if there is a focuser. If not, return "No Focuser".
	// Otherwise, run @Focus2.
	//
	{
		focTemp = ccdsoftCamera.focTemperature.toFixed(1);
		focPos = ccdsoftCamera.focPosition;
	}

	if ( SelectedHardware.filterWheelModel !== "<No Filter Wheel Selected>" )
	//
	// This test looks to see if there is a filter wheel. If not, return "NA".
	// Otherwise, give us the filter name for the main script's pretty printing.
	//
	{
		filter=ccdsoftCamera.szFilterName(ccdsoftCamera.FilterIndexZeroBased);	
	} 

	out = "Stats: Filter=" + filter + ", Temp=" + focTemp + ", FocPos=" + focPos + ", FWHM=NaN" + "; " + path;
}

/* Socket End Packet */
