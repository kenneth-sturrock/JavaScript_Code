/* Java Script */
/* Socket Start Packet */

//
// I got really tired of answering the same questions from people who didn't bother 
// to read the (admitedly long-winded) README.pdf file.
//
// This Javascript is called by the "pre-run" function to check (and change) particular
// settings that are needed for the script to operate.
//
// Ken Sturrock
// January 13, 2018
//

var obsName = "Not Set";
var teleFL = 0;
var guideFL = 0;
var cr = "\n";
var out = "";
var camSavePath="";
var guideSavePath="";
var camWhiteSpace="";
var guideWhiteSpace="";
var camSessionDateFolder="";
var guideSessionDateFolder="";

obsName = ccdsoftCamera.PropStr("m_csObserver");
teleFL = ccdsoftCamera.PropDbl("m_dTeleFocalLength");
guideFL = ccdsoftAutoguider.PropDbl("m_dTeleFocalLength");
camSavePath=ccdsoftCamera.PropStr("m_csAutoSavePath");
guideSavePath=ccdsoftAutoguider.PropStr("m_csAutoSavePath");
camWhiteSpace=ccdsoftCamera.PropLng("m_bAutoSaveNoWhiteSpace");
guideWhiteSpace=ccdsoftAutoguider.PropLng("m_bAutoSaveNoWhiteSpace");
camCollectDate = ccdsoftCamera.PropStr("m_csAutoSaveColonaDateFormat");
guideCollectDate = ccdsoftAutoguider.PropStr("m_csAutoSaveColonaDateFormat");

if ( ! obsName )
{
	out += "NOTE: Please set the Observer Name under the Camera settings." + cr;
}

if ( ! teleFL )
{
	out += "NOTE: Please set the Telescope Focal Length under the Camera settings." + cr;
}

if ( ! guideFL )
{
	out += "NOTE: Please set the Telescope Focal Length under the Autoguider settings." + cr;
}

 
if (camSavePath.indexOf(' ') >= 0)
{
	out += "NOTE: Please remove any spaces in the Camera\'s Autosave Folder Name." + cr;
}

if (guideSavePath.indexOf(' ') >= 0)
{
	out += "NOTE: Please remove any spaces in the Autoguider\'s Autosave Folder Name." + cr;
}

if (camWhiteSpace == 0)
{
	ccdsoftCamera.setPropLng("m_bAutoSaveNoWhiteSpace", 1)
}

if (guideWhiteSpace == 0)
{
	ccdsoftAutoguider.setPropLng("m_bAutoSaveNoWhiteSpace", "1")
}

if (camCollectDate.indexOf(' ') >= 0)
{
	out += "NOTE: Please remove any spaces in the Camera\'s Autosave date file format." + cr;
}

if (guideCollectDate.indexOf(' ') >= 0)
{
	out += "NOTE: Please remove any spaces in the Guider\'s Autosave date file format." + cr;
}

ccdsoftAutoguider.setPropLng("m_bShowAutoguider", "1")

if (out == "")
{
	out = "No Configuration Issues."
}

out

/* Socket End Packet */

