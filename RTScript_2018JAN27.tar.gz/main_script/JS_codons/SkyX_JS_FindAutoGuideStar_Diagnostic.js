
	
//
// Try to find a decent guide star using a mash-up of code from Colin McGill, Kym Haines and Ken Sturrock. 
// 
// NOTE: The diagnostic version of this script can take a SIGNIFICANT amount of time to run due to the ouput 
// statements - especially on old/small/slow machines.
//
// This is a diagnostic version for testing routines and is NOT designed to be called from run_target.
//
// If you are loading your own previously saved (non-DSS) images from disk, ensure that the guider
// is not set to use DSS images or the Y axis will be flipped unnecessarily.
//
// If you're taking the image "live", remember to save the image or have autosave activated.
//
// Formatted to look "less bad" in the SkyX JS Environment, may look terrible in other editors.
//
// Ken Sturrock
// January 13, 2018
//
 
//
//  Identify which picture to use and call the light source inventory routine for the picture
//
ccdsoftAutoguiderImage.AttachToActive();
ccdsoftAutoguiderImage.ShowInventory();
 
//
// Identifies the positions for each variable in the returned inventory results.
//
var X   = ccdsoftAutoguiderImage.InventoryArray(0);
var Y   = ccdsoftAutoguiderImage.InventoryArray(1);
var Mag     = ccdsoftAutoguiderImage.InventoryArray(2);
var FWHM    = ccdsoftAutoguiderImage.InventoryArray(4);
var Elong = ccdsoftAutoguiderImage.InventoryArray(8);
 
//
// The median function uses a sort which rearranges the array fed to it.
// These are duplicate, but disposable, variables that can be fed to the median
// function without jacking up the original arrays for later use.
//
var disposableMag   = ccdsoftAutoguiderImage.InventoryArray(2);
var disposableFWHM  = ccdsoftAutoguiderImage.InventoryArray(4);
var disposableElong = ccdsoftAutoguiderImage.InventoryArray(8);
 
//
// Determine image width and height
//
var Width       = ccdsoftAutoguiderImage.WidthInPixels;  
var Height      = ccdsoftAutoguiderImage.HeightInPixels;
 
function median(values)
//
// Calculate the median value of an array.
//
// Stolen from code by caseyjustus and mviktora at the URL: 
//
//    https://gist.github.com/caseyjustus/1166258
//
{
    values.sort( function(a,b) {return a - b;} );
 
    var half = Math.floor(values.length/2);
 
    if(values.length % 2)
    {
        return values[half];
 
    } else {
 
       return (values[half-1] + values[half]) / 2.0; 
    }
}
 
 
function QMagTest(ls)
//
// Function to test a star magnitude and make sure not saturated and not too dim
// 
// This function was written by Colin McGill, but I butchered its sleek K&R style 
// when I added diagnostic code.
//
{
    // Loops over pixels near star to see how many are over GuideMax
    //
    var Ix = 0;       // Counter
    var Iy = 0;       // Counter
    var Isat = 0;     // Number of points oversaturation limit
    var Msat = 0.0;   // Maximum level observed
 
    for (Ix = Math.max(0,Math.floor(X[ls]-FWHM[ls]*2+.5)); Ix < Math.min(Width-1,X[ls]+FWHM[ls]*2); Ix++ ) 
    {
        for (Iy = Math.max(0,Math.floor(Y[ls]-FWHM[ls]*2+.5)); Iy < Math.min(Height-1,Y[ls]+FWHM[ls]*2); Iy++ ) 
        {
            if (ImgVal[Iy][Ix] > Msat) Msat = ImgVal[Iy][Ix];
            if (ImgVal[Iy][Ix] > GuideMax) Isat++;
        }
    } 
      
    if (Isat > 1)
    // 
    // One saturated pixel is allowed.
    //
    {
 
        ADUFail = ADUFail + 1;
 
        DiagnosticReport += "     ADU Test: Failed " + cr;
        DiagnosticReport += "        Maximum Pixel ADU: " + Msat + cr;
        DiagnosticReport += "        Number of Saturated Pixels: " + Isat + cr;
 
        return false;
 
    } else {
 
        DiagnosticReport += "     ADU Test: Passed " + cr;
        DiagnosticReport += "        Maximum Pixel ADU: " + Msat + cr;
        DiagnosticReport += "        Number of Saturated Pixels: " + Isat + cr;
       
        return true;
    }
}
 
 
//
// Define other variables and "safe" initial values.
//
var FlipY               = "No"                                               // Set to Yes if we need to flip the Y axis 
                                     					     //  DSS images are checked for below
var out             = "";                                                    // Setup a blank starter variable for building 
                                                                             // The output string
var DiagnosticReport    = "";                                                // Used for optional troubleshooting.
var cr                  = "\n";                                              // Set this variable to represent a newline 
var Brightest           = 0;                                                 // Placeholder for the index number representing the brightest Light Source. 
                                                                             // If no light sources pass (or there is only one), then this is the fallback.
var newX                = 0;                                                 // Holds the final, flipped, X for output.
var newY                = 0;                                                 // Holds the final, flipped, Y for output.
var counter             = X.length;                                          // How many light sources do we have?
var passedLS            = 0;                                                 // How many light sources have passed all the tests
var ADUFail                 = 0;                                             // How many are failed by the ADU test
var medFWHM             = median(disposableFWHM);                            // Median FWHM for candiate star comparisons
var medMag                  = median(disposableMag);                         // Median brightness for candiate star comparisons      
var medElong            = median(disposableElong);                           // Median elongation for candidate star comparisons
var baseMag                 = medMag;                                        // Starting point for lowest acceptable magnitude
var halfTBX                 = (ccdsoftAutoguider.TrackBoxX / 2) + 5;         // Determine the allowable "neighbor distance" from LS in X
var halfTBY                 = (ccdsoftAutoguider.TrackBoxY / 2) + 5;         // Same for Y
var distX               = 0;                                                 // Holds the distance between light source and neighbor in X
var distY               = 0;                                                 // Holds the distance between light source and neighbor in Y
var pixDist                 = 0;                                             // Holds the diagonal distance between the two points for pretty printing.
var failCount               = 0;                                             // Have any close bright neighbors been found?
var magLimit                = 0;                                             // What is the brigthest neighboring star that we allow for each light source?
var k                       = 0;                                             // Holds the array index during the neighbor search
 
//
// The next few sections are part of Colin McGill's saturation check contribution.
//
// Read in the image to allow a check against maximum values
// Will be creating an array of arrays to simulate a 2D array.
//
var ImgVal      = new Array(Height);                                        // ImgVal will hold image values
var Ix, Iy          = 0;                                                    // Counter
var GuideBits   = ccdsoftAutoguiderImage.FITSKeyword("BITPIX"); 			   // Number of bits in image to work out maximum value
var GuideCamMax     = Math.pow(2,GuideBits)-1;                              // Maximum value of camera
var GuideMax        = GuideCamMax * 0.9;                                    // Maximum allowed value for a star
 
for (Ix = 0; Ix < Height; Ix++) 
// 
// Read lines one at a time. Builds pixel array for Colin's saturated pixel code
//
{
    ImgVal[Ix] = ccdsoftAutoguiderImage.scanLine(Ix);
}
 
// To make nearest neighbour searching better, make an array of nearby stars
// Create a coarse grid and save star indices in the grid
var NcoarseX   = Math.floor(Width/halfTBX+1);      // Number of X cells in coarse array
var NcoarseY   = Math.floor(Height/halfTBY+1);     // Number of Y cells in coarse grid
 
var CoarseArray = new Array(NcoarseX);             // Coarse Array X dimension
for (Ix = 0; Ix < NcoarseX; Ix++)                  // Now create array of Y dimensions
{
    CoarseArray[Ix] = new Array(NcoarseY);
    for (Iy = 0; Iy < NcoarseY; Iy++) CoarseArray[Ix][Iy] = new Array();
}
 
// Now Populate the array with star indices
for (ls = 0; ls < counter; ls++) {
    // Determine the index of each star in the coarse grid
    Ix = Math.floor(X[ls]/halfTBX);
    Iy = Math.floor(Y[ls]/halfTBY);
 
// Now save the index of that star in that array location
    CoarseArray[Ix][Iy].push(ls);
}
 
 
function QNeighbourTest(ls)
//
// Function to test whether a star has near neighbours
// 
{
    var Ix, Iy, Is; /// Counters
    var MagLimit = (Mag[ls] + medMag) / 2.5;            // Change the "2.5" to a smaller number if too many stars are screened out.
    var distX, distY, pixDist;                          // Distances
    var Nstar;                                          // Number of stars in the coarse grid block
    var Istar;                                          // Index of star in coarse grid block
 
// Determine location of star in coarse grid
    var Isx = Math.floor(X[ls]/halfTBX);
    var Isy = Math.floor(Y[ls]/halfTBY);
 
// Determine range of coarse cells to examine
    var Ixmin = Math.max(0,Isx-1);
    var Ixmax = Math.min(NcoarseX-1,Isx+1);
    var Iymin = Math.max(0,Isy-1);
    var Iymax = Math.min(NcoarseY-1,Isy+1);
 
// Loop over these cells and stars within these cells
    for (Ix = Ixmin; Ix < Ixmax; Ix++) {
    for (Iy = Iymin; Iy < Iymax; Iy++) {
        Nstar = CoarseArray[Ix][Iy].length;
        for (Is = 0; Is < Nstar; Is++) {
        Istar = CoarseArray[Ix][Iy][Is];
        if (Istar != ls) { // Don't bother checking ourselves
             
            distX = Math.abs(X[ls] - X[Istar]);
            distX = distX.toFixed(2);
            distY = Math.abs(Y[ls] - Y[Istar]);
            distY = distY.toFixed(2);
             
            pixDist = Math.sqrt((distX * distX) + (distY * distY));
            pixDist = pixDist.toFixed(2);
             
            if (  distX > halfTBX ||  distY > halfTBY || Mag[k] > MagLimit) {
            //
            // If the distance between the candidate light source and all of the other
            // light sources is less than half the size of the guider tracking box (plus buffer)
            // in both axes or the neighbor is brighter than the average of the image and the  
            // candidate light source - then reject it as a neighbor and mark the compared light 
            // source as "rejected".
            // 
            // If the light source compared to the candidate meets the criteria above (far 
            // away or dim) then mark the comparison light source as "approved".
            //
            // If there are any rejected light sources after this neighbor search then
            // the candidate light source will be rejected.
            //                         
                DiagnosticReport += "          Accepted: LS[" + Istar + "]"
                + " (" + X[Istar] + "," + Y[Istar] + ")" + " Distance: "
                    + pixDist + " "
                    + " Mag: " + Mag[Istar] + cr;
             
                } else {
                DiagnosticReport += "X         Rejected: LS[" + Istar + "]"
                + " (" + X[Istar] + "," + Y[Istar] + ")" + " Distance: "
                    + pixDist + " "
                    + " Mag: " + Mag[Istar] + cr;
             
                return (false);        
                }
        }
        }
    }
    }
 
// Has passed neighbour test - return true!
    return (true);
}
 
 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Start the main procedure, finally.........
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
DiagnosticReport += "------------------------------------------------------------------------------------------------------------------" + cr;
DiagnosticReport += "Start Light Source Analysis & Guide Start Selection" + cr;
DiagnosticReport += "------------------------------------------------------------------------------------------------------------------" + cr;
 
 
for (ls = 0; ls < counter; ++ls)
//
// Set up the loop through the identified light sources
//
{
    DiagnosticReport += cr;
    DiagnosticReport += cr + "LS[" + ls + "] - " + "X:" + X[ls] + " "
        + "Y:" + Y[ls] + " " + "Mag:" + Mag[ls] 
        + " " + "FWMH:" + FWHM[ls] + cr;
 
 
    if ( Mag[ls] < medMag )
    //
    // Screen out the dim half of the stars in the image
    //
    {
        DiagnosticReport += "     Minimum Brightness Pass" + cr;
  
        if (((X[ls] > 30 && X[ls] < (Width - 30))) && (Y[ls] > 30 && Y[ls] < (Height - 30))) 
        //     
        // No stars near edges
        //
        {
            DiagnosticReport += "     Edge Proximity Pass" + cr;
 
            if ((Elong[ls] < medElong * 2.5))
            // 
            // Nothing too oval.
            //
            {
                DiagnosticReport += "     Elongation Pass" + cr;
 
     
                if (FWHM[ls] < (medFWHM * 2.5) && (FWHM[ls] > 1)) 
                //
                // Nothing too bloated or tight - These values can be tweaked to select more or fewer stars.
                //
                {
                    DiagnosticReport += "     FWHM Pass" + cr;
 
                    if ( QMagTest(ls) ) {
                    //
                    // Screen out any saturated light sources.
                    //
 
                        DiagnosticReport += "     Checking for Neighbors:" + cr + cr;
 
                        if ( QNeighbourTest(ls)) 
							 {
                        		DiagnosticReport += cr + "     Neighbor Check: Passed" + cr + cr;
                        		passedLS = passedLS + 1;        // Tally it as a pass for the final count
                         
                        	   if (Mag[ls] < baseMag)
                              //
                              // If the candidate star survived the gauntlet above, set it to the new 
                              // brightest star if it is, in fact, brighter than the last one.
                              //
                              { 
                            		baseMag = Mag[ls];
                            		Brightest = ls;
                         
                            		DiagnosticReport += "*    " + "LS[" + ls + "] is NOW the Brightest!    *" + cr; 
                         
                              } else {
                         
                            		DiagnosticReport += "     " + "LS[" + ls + "] is NOT the Brightest" + cr; 
                        
							    	}
                       
							  } else {    
                       
							     	DiagnosticReport += cr + "     Neighbor Check: Failed (" + failCount + ")" + cr;
                         
                         }
 
                    }
                }
            }
        }  
    }
}
 
 
 
//
// Create output statement
//
 
if ( ccdsoftAutoguider.ImageUseDigitizedSkySurvey == "1" ) 
//
// Test to see if the image is a DSS image and we, therefore, have to flip it below
// by setting FlipY to "yes".
//
{
    FlipY = "Yes";
 
    var Binned = ccdsoftAutoguiderImage.FITSKeyword ("XBINNING");
     
    if ( Binned > 1 )
    //
    // Binning of DSS images is performed by SkyX and those files are NOT
    // flipped.
    //
    {
        FlipY = "No";
    }
}
 
 
if (FlipY == "Yes") 
//
// Flip axis if needed
//
{
    newY = (Height - Y[Brightest]);
 
} else {
 
    newY = Y[Brightest];
}
 
//
// Clean up any ridiculously over-precise decimals 
//  
newY = newY.toFixed(2);
newX = X[Brightest].toFixed(2);
medFWHM = medFWHM.toFixed(2);
Mag[Brightest] = Mag[Brightest].toFixed(2); 
newMedMag = medMag.toFixed(2);
 
ccdsoftAutoguider.GuideStarX = newX * ccdsoftAutoguiderImage.FITSKeyword ("XBINNING") ; 
ccdsoftAutoguider.GuideStarY = newY * ccdsoftAutoguiderImage.FITSKeyword ("YBINNING") ; 
 
//
// Assemble the variable for the output statement
//
 
DiagnosticReport += cr + "------------------------------------------------------------------------------------------------------------------" + cr;
 
DiagnosticReport += cr + "Chosen source coordinates copied to the autoguider's 'Use Guide Star' fields." + cr; 
 
DiagnosticReport += cr + "------------------------------------------------------------------------------------------------------------------" + cr + cr;
 
out += DiagnosticReport;
out += "Chosen Source: LS[" + Brightest + "], ";
out += "X=" + newX + ", ";
out += "Y=" + newY 
 
if (FlipY == "Yes") 
//
// Tell user it is flipped
//
{
    out += " (DSS FLIPPED), ";
}
 
out += "LS Mag=" + Mag[Brightest] + ", "; 
out += "Median Mag=" + newMedMag + ", "; 
out += "LS FWHM=" + FWHM[Brightest] + ", "; 
out += "Median FWHM=" + medFWHM + ", "; 
out += "Total LSs:" + counter + ", "; 
out += "Saturated LSs:" + ADUFail + ", ";
out += "Passed LSs:" + passedLS + cr;

