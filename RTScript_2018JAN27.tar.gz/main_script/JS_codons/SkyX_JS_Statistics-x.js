/* Java Script */


var cr = "\n";
var out = "";
var tab = "\t";

if ( ccdsoftCamera.ImageUseDigitizedSkySurvey == "0" ) 
//
// Don't try to Image Link the DSS imgaes. It often fails.
//
{

	ccdsoftCameraImage.AttachToActiveImager();

	ImageLink.pathToFITS = ccdsoftCameraImage.Path;

	ImageLink.execute();

	if ( ImageLinkResults.Succeeded == 0 )
	{
		out = "^          Image Link Failed: " + ImageLinkResults.errorText;

	} else {

		var imageScale = ImageLinkResults.imageScale;
		var imageCenterRA = ImageLinkResults.imageCenterRAJ2000;
		var imageCenterDec = ImageLinkResults.imageCenterDecJ2000;
		var ilFWHM = ImageLinkResults.imageFWHMInArcSeconds;
		var ilPosAng = ImageLinkResults.imagePositionAngle;

		var ASIlFWHM = ilFWHM * imageScale

		sky6Utils.ConvertEquatorialToString(imageCenterRA, imageCenterDec, 5);

		var centerHMS2k = sky6Utils.strOut;

		sky6Utils.Precess2000ToNow( imageCenterRA, imageCenterDec);

		var centerLSRANow = sky6Utils.dOut0;
		var centerLSDecNow = sky6Utils.dOut1;

		sky6Utils.ConvertEquatorialToString(centerLSRANow, centerLSDecNow, 5);	

		var centerHMSNow = sky6Utils.strOut;

		out = "^          Image Scale: " + tab + tab + imageScale.toFixed(1) + " AS/px" + cr;
		out += "          Image FWHM: " + tab + tab + ASIlFWHM.toFixed(1) + " AS" + cr;

   		out += "          Now -  " + centerHMSNow + cr;
   		out +="          j2k -  " + centerHMS2k;

	}

} else {

	out = "^          DSS Image. No Image Link analysis performed.";
}
