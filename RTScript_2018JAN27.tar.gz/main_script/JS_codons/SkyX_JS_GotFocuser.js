/* Java Script */
/* Socket Start Packet */

//	
//	Is there a focuser attached to the system?
//
//	Ken Sturrock 
//	January 13, 2018
//

SelectedHardware.focuserModel

/* Socket End Packet */

