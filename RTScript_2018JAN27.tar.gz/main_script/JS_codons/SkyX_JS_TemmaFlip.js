/* Java Script */
/* Socket Start Packet */

//
// This script is a 100% bogus hack for very slow slewing small 12v Takahashi Temma Mounts.
//
// The issue is that if you're using a slow and/or old Takahashi Temma, then @Focsu2 will time out just like CLS
// does since a meridian flip on a slow Temma can take about 12 minutes. This Javascript is, therefore, called by
// the main script so that: If you are using a slow Temma then the mount will pre-slew to a target west of the actual 
// target. 
//
// The script may then call @Focus2 as usual, which will give you the benefit of a focus in the right neighborhood
// (but not so close to the meridian that it might try to re-flip to acquire a guide star on the wrong side). The
// return to target CLS will then have to move the mount about two hours, which it can do without a time-out.
//
// It is best to put your Temma in 24v "fast" mode to reduce the time-out issue, although this code will still
// execute if you're using a Temma.
//
// Ken Sturrock
// Jaunary 13, 2018
//

var targetRA;					// Use final for target RA
var targetDEC;					// Final target DEC
var westOfTargetRA;				// An RA west of final target
var CLSStatus;					// CLS Error status
var repErr;					// Throw away error message
var targetStr;
var myMount = SelectedHardware.mountModel;

if ( myMount.indexOf('Temma') >= 0 )
//
// Only do this if you are using a Temma. Yes, every Temma is stuck with this kludge.
// Sorry. If the SkyX drivers were more specific, I'd work around it.
//
{
	sky6RASCOMTele.Asynchronous = true;

	sky6ObjectInformation.Property(54);
		targetRA = sky6ObjectInformation.ObjInfoPropOut;

	sky6ObjectInformation.Property(55); 				
		targetDEC = sky6ObjectInformation.ObjInfoPropOut; 		

	westOfTargetRA = targetRA - 1.5;

	sky6RASCOMTele.SlewToRaDec(westOfTargetRA, targetDEC, "Slew"); 

	while (sky6RASCOMTele.IsSlewComplete == 0)
	//
	// If the mount is still moving, wait for it to finish before handing things off to the next process
	//
	{	
		sky6Web.Sleep (10000);						// Hang out. 
	}

	sky6RASCOMTele.Asynchronous = false;

	targetStr = westOfTargetRA + ", " +  targetDEC;

	sky6StarChart.Find(targetStr);

	ccdsoftCamera.Delay = 10;	

	try
	//
	// Try to closed-loop-slew to the target and catch the error if it fails.
	//
	{ 
		ClosedLoopSlew.exec(); 
	}
	
		catch (repErr)
		//
		// We're going to use our throw away variable repErr to
		// swallow the actual error message and substitute it for a generic
		// failure message.
		// 
		{
			CLSStatus = "Failed";
		}

	ccdsoftCamera.Delay = 1;

	if ( CLSStatus !== "Failed" )
	//
	// Do the right thing if the CLS passes or fails.
	//
	{
			
		sky6RASCOMTele.Sync(westOfTargetRA, targetDEC, "West");

		out = "Temma";	

	} else {

		out = "Failed"
	}

} else {
	out = "NO";
}

/* Socket End Packet */


