/* Java Script */
/* Socket Start Packet */

//	
//	Run @Focus2. If @Focus2 does not run in fully automatic mode (exposure and star selection)
//	this routine will not work. If you don't want to use it, set the useAtFocus variable
//	in the run_target bash script to "no".
//
//	This script will not magically make @Focus2 work if it doesn't already.
//
//	$000 will be replaced by tsxfeeder with the luminance filter
//	$001 will be replaced with the binning value
//
//	Ken Sturrock 
//	January 13, 2018
//


var CCDSC		= ccdsoftCamera;
var myMount		= SelectedHardware.mountModel;		// What mount are we using? Used for Temma oddness.
var initExp 		= CCDSC.ExposureTime;			// How long of an exposure does the camera use?
var binFactor 		= "$001"
var initialBinX		= CCDSC.BinX;
var initialBinY		= CCDSC.BinY;

if ( SelectedHardware.filterWheelModel !== "<No Filter Wheel Selected>" )
//
// Screen out systems that have an automatic focuser but not a filter wheel.
// 
{
	CCDSC.FilterIndexZeroBased = $000; 	// set in main script
} 

// The command below sets calibration to none. I set this as the default option 
// because so many users have cameras without a mechanical shutter.
//
// If your imaging camera has a mechanical shutter then you should go ahead and change 
// the zero to a one.

CCDSC.ImageReduction = 0;

if (CCDSC.PropStr("m_csObserver") == "Ken Sturrock")
//
// This pulls the "observer name" to see if it's me. It then sets my defaults up for specific
// equipment so that I can leave the variables in the main script generic for others.
//
// This shouldn't have any effect on you unless your name is also "Ken Sturrock" and you have the same 
// gear that I have. Just leave it alone, unless you want to change it for specific gear you own.
//
{

	if ( SelectedHardware.cameraModel == "SBIG ST-2000XM" ) 
	//
	// Set this for my ST-2k setup 
	//
	{
		CCDSC.ImageReduction = 1;
		CCDSC.FilterIndexZeroBased = 3; 	
	}	

	if ( SelectedHardware.cameraModel == "QSI Camera  " ) 
	//
	// Set this for my QSI setup
	//
	{
		CCDSC.ImageReduction = 1;
		CCDSC.FilterIndexZeroBased = 0; 
	} 

}

if ( SelectedHardware.focuserModel !== "<No Focuser Selected>" )
//
// This test looks to see if there is a focuser as a final fail-safe
//
// Again - if you don't have a focuser or don't want to focus what you have, 
// then it is best to set the useAtFocus variable in the main script!
//
{

	if ( CCDSC.ImageUseDigitizedSkySurvey == "1" )
	//
	// Just pretend to focus since we're simulating images and it will fail anyway.
	//
	{
		out = "Simulator";

	} else {


		if ( myMount.indexOf('Temma') >= 0 )
		//
		// More fabulous Temma flip-flop protection.
		//
		// One night, I watched my EM-200 flip back and forth across the meridian with a flip
		// because the focus star was located west of the meridian and the temperature changes
		// caused frequent re-focuses. The EM-11, running in "slow mode" would have failed.
		//
		// This simply pulls the mount away from the meridian before running @Focus2 with the
		// hope that it is less likely to flip across the meridian to focus.
		//
		// Yeah. Right....
		//
		{

			sky6ObjectInformation.Property(59);  
    			var altitude = sky6ObjectInformation.ObjInfoPropOut;

			altitude = altitude.toFixed(1);

			sky6ObjectInformation.Property(58);  
    			var azimuth = sky6ObjectInformation.ObjInfoPropOut;

			if ((azimuth < 180) && ((azimuth <= 10) || (azimuth >= 170)))
			//
			// Are we just east of meridian? If so, pull us back to the east before a focus.
			//
			{
				sky6ObjectInformation.Property(54);
				var targetRA = sky6ObjectInformation.ObjInfoPropOut;

				sky6ObjectInformation.Property(55); 				
				var targetDEC = sky6ObjectInformation.ObjInfoPropOut; 		

				var eastOfTargetRA = targetRA + 0.6;

				sky6RASCOMTele.SlewToRaDec(eastOfTargetRA, targetDEC, "east_of_target"); 

			}

			if  ((azimuth >= 180) && ((azimuth <= 190) || (azimuth >= 350)))
			//
			// Are we just west of the meridian? If so, pull us forward to the west before running a focus.
			//
			{
				sky6ObjectInformation.Property(54);
				var targetRA = sky6ObjectInformation.ObjInfoPropOut;

				sky6ObjectInformation.Property(55); 				
				var targetDEC = sky6ObjectInformation.ObjInfoPropOut; 		

				var westOfTargetRA = targetRA - 0.6;

				sky6RASCOMTele.SlewToRaDec(westOfTargetRA, targetDEC, "west_of_target"); 

			}

		}


		//
		// The section below takes a throw-away light-frame with the chosen base filter.
		// If you don't take a normal image then @Focus2 will not apply the focuser offset for
		// the filter. THis may mean the starting position will be "more bad" but it also means that,
		// in case of focus failure, the focuser will not be set for the present filter and the next light
		// frame taken after the failed focus will be taken with an offset applied ontop of the wrong
		// recycled base position.
		//
		// OK, that makes little sense. Just pretend that you never read it.
		//
		CCDSC.AutoSaveOn = false;		// Toss the image for this one single frame
		CCDSC.ExposureTime = 1;			// Set duration for a throw-away light frame
			
		CCDSC.TakeImage();			// Snap the throw-away

		CCDSC.AutoSaveOn = true;		// Keep the images for the future
		CCDSC.ExposureTime = initExp;		// Restore camera duration time. It'll get set later anyway...


		if ( binFactor == "Yes" )
		//
		// Are we binning 2x2 for a OSC camera?
		//
		{
			ccdsoftCamera.setPropLng("m_nXBin", "2" );
			ccdsoftCamera.setPropLng("m_nYBin", "2" );
		}

	

		// Finally! Focus the camera!	
		out = CCDSC.AtFocus();	


		if ( binFactor == "Yes" )
		//
		// If we binned the camera for focusing, put it back.
		//
		{
			ccdsoftCamera.setPropLng("m_nXBin", "initialBinX" );
			ccdsoftCamera.setPropLng("m_nYBin", "initialBinY" );
		}
	}

} else {

	out = "No Focuser";	 
}

out

/* Socket End Packet */

