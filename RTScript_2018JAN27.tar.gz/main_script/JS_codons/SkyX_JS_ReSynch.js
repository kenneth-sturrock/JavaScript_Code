/* Java Script */
/* Socket Start Packet */

// This touches up the pointing on my Temma.
//
// As written, it does NOTHING unless you have a Takahashi Temma
//
// Ken Sturrock 
// January 13, 2018
//


var myMount= SelectedHardware.mountModel;

if (  myMount.indexOf('Temma') >= 0 )
//
// If using a Takahashi Temma, then re-synchronize goto after a CLS.
//
{
	sky6ObjectInformation.Property(0);  
	targetName = sky6ObjectInformation.ObjInfoPropOut;

	sky6ObjectInformation.Property(54);  
	targetRA = sky6ObjectInformation.ObjInfoPropOut;

	sky6ObjectInformation.Property(55);  
	targetDec = sky6ObjectInformation.ObjInfoPropOut;

	sky6RASCOMTele.Sync(targetRA, targetDec, targetName);

	out = targetName;

} else {
	out = "NO";
}

/* Socket End Packet */
