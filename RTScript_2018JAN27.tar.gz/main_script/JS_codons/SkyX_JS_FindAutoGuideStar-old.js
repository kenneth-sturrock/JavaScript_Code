/* Java Script */
/* Socket Start Packet */

//
// Try to find a decent guide star using a mash-up of code from Colin McGill, Kym Haines and Ken Sturrock. 
// 
// This is the compressed version for use by the script. If you're trying to figure this script out
// or reverse engineer it, please look at the "diagnostic" version which is meant to run from the 
// SkyX's JS environment.
//
// Ken Sturrock
// August 23, 2017
//

var CAGI = ccdsoftAutoguiderImage;


CAGI.AttachToActiveAutoguider();
CAGI.ShowInventory();


var X  	= CAGI.InventoryArray(0);
var Y  	= CAGI.InventoryArray(1);
var Mag  	= CAGI.InventoryArray(2);
var FWHM 	= CAGI.InventoryArray(4);
var Elong = CAGI.InventoryArray(8);


var dispMag  	= CAGI.InventoryArray(2);
var dispFWHM 	= CAGI.InventoryArray(4);
var dispElong	= CAGI.InventoryArray(8);


var Width		= CAGI.WidthInPixels;  
var Height   	= CAGI.HeightInPixels;

function median(values)
{
	values.sort( function(a,b) {return a - b;} );

	var half = Math.floor(values.length/2);

	if(values.length % 2)
 	{
  		return values[half];

	} else {

       return (values[half-1] + values[half]) / 2.0; 
 	}
}


function QMagTest(ls)

{
 	var Ix = 0;       
 	var Iy = 0;       
 	var Isat = 0;     
 	var Msat = 0.0;   

 	for (Ix = Math.max(0,Math.floor(X[ls]-FWHM[ls]*2+.5)); Ix < Math.min(Width-1,X[ls]+FWHM[ls]*2); Ix++ ) 
 	{
  		for (Iy = Math.max(0,Math.floor(Y[ls]-FWHM[ls]*2+.5)); Iy < Math.min(Height-1,Y[ls]+FWHM[ls]*2); Iy++ ) 
  		{
   			if (ImgVal[Iy][Ix] > Msat) Msat = ImgVal[Iy][Ix];
   			if (ImgVal[Iy][Ix] > GuideMax) Isat++;
      	}
	} 
     
	if (Isat > 1)
 	{

  		return false;

 	} else {

      	return true;
 	}
}



var FlipY  				= "No"												 
        																	
var out   			 	= "";     										
        																	
var cr    				= "\n";										
var Brightest  			= 0;     											
																				
var newX   				= 0;											
var newY   				= 0;												
var counter   			= X.length;    									  										
var medFWHM   			= median(dispFWHM);  					       
var medMag   				= median(dispMag);  							    
var medElong   			= median(dispElong);  							
var baseMag  				= medMag;    										
var halfTBX  				= (ccdsoftAutoguider.TrackBoxX / 2) + 5; 	
var halfTBY  				= (ccdsoftAutoguider.TrackBoxY / 2) + 5;	
var distX 				= 0;												
var distY 				= 0;												
var failCount				= 0;											
var magLimit				= 0;												
var k						= 0;												


var ImgVal 		= new Array(Height);									
var Ix 			= 0;														
var GuideBits 	= CAGI.FITSKeyword("BITPIX");							
var GuideCamMax 	= Math.pow(2,GuideBits)-1;							
var GuideMax 		= GuideCamMax * 0.9;									

for (Ix = 0; Ix < Height; Ix++) 
{
    ImgVal[Ix] = CAGI.scanLine(Ix);
}


for (ls = 0; ls < counter; ++ls)
{
		+ "Y:" + Y[ls] + " " + "Mag:" + Mag[ls] 
		+ " " + "FWMH:" + FWHM[ls] + cr;


	if ( Mag[ls] < medMag )
	{
 
 		if (((X[ls] > 30 && X[ls] < (Width - 30))) && (Y[ls] > 30 && Y[ls] < (Height - 30))) 
 		{

  			if ((Elong[ls] < medElong * 2.5))
  			{

    
    			if (FWHM[ls] < (medFWHM * 2.5) && (FWHM[ls] > 1)) 
    			{

    				if ( QMagTest(ls) )
    				{

     					failCount = 0;
       				magLimit = (Mag[ls] + medMag) / 2; 

						for (k = 0; k < counter; ++k)
                  	{
							if (k != ls)
        					{
								distX = Math.abs(X[ls] - X[k]);
									distX = distX.toFixed(2);
								distY = Math.abs(Y[ls] - Y[k]);
									distY = distY.toFixed(2);

								if (  distX > halfTBX ||  distY > halfTBY || Mag[k] > magLimit)
        						{                         
										// Do nothing and let it pass. In the diagnostic version, this would print output.
   
        						} else {

         								failCount = failCount + 1;         
        						}
 
       					} 

     					}
    
     					if ( failCount > 0)
     					{

							// Do nothing. It failed. In the diagnostic version, it prints a message.

     					} else {	
      
      						if (Mag[ls] < baseMag)
      						{ 
       						baseMag = Mag[ls];
       						Brightest = ls;
      						} 

     					}
    				}
   				}
  			}  
 		}
	}
}


if ( ccdsoftAutoguider.ImageUseDigitizedSkySurvey == "1" ) 
{
	FlipY = "Yes";

	var Binned = CAGI.FITSKeyword ("XBINNING");
	
	if ( Binned > 1 )
 	{
  		FlipY = "No";
 	}
}


if (FlipY == "Yes") 
{
	newY = (Height - Y[Brightest]);

} else {

	newY = Y[Brightest];
}

newY = newY.toFixed(2);
newX = X[Brightest].toFixed(2);
medFWHM = medFWHM.toFixed(2);
Mag[Brightest] = Mag[Brightest].toFixed(2); 
newMedMag = medMag.toFixed(2);
path = CAGI.Path;	
out += "X=" + newX + ",";
out += "Y=" + newY + ",,,,,;";
out += "Path=" + path + cr;

/* Socket End Packet */

