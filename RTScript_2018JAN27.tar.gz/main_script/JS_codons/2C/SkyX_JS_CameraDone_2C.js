/* Java Script */
/* Socket Start Packet */

//	
//	This JavaScript just checks if the second camera is done
//	and we can move the mount.
//
//	Ken Sturrock 
//	January 13, 2018
//

ccdsoftCamera.State

/* Socket End Packet */

