/* Java Script */
/* Socket Start Packet */

//	
//	Disconnect the second camera and mount	
//
//	Ken Sturrock 
//	January 13, 2018
//

ccdsoftCamera.Disconnect();
sky6RASCOMTele.Disconnect();


/* Socket End Packet */

