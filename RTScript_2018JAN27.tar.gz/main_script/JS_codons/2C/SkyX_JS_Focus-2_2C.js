/* Java Script */
/* Socket Start Packet */

//
// Stripped down focus routine for a second opportunistic camera
//
// Ken Sturrock
// January 13, 2018
//

var af2SlewSetting = ccdsoftCamera.PropLng("m_baf2AutoSlew");	// Store the current AF2 autoslew setting
var out = "No Focuser";

ccdsoftCamera.Asynchronous = false;				// Wait for results	
ccdsoftCamera.setPropLng("m_baf2AutoSlew", 0);			// Turn off the AF2 auto-slew

if ( SelectedHardware.focuserModel !== "<No Focuser Selected>" )
//
// Skip this if there is no focuser for the second camera.
//
{
	ccdsoftCamera.focConnect();

	if ( ccdsoftCamera.ImageUseDigitizedSkySurvey == "1" )
	//
	// Just pretend to focus since we're simulating images and it will fail anyway.
	//
	{
		out = "Simulator";

	} else {

		out = ccdsoftCamera.AtFocus();	// Finally! Focus the camera!	
	}

} 


ccdsoftCamera.setPropLng("m_baf2AutoSlew", af2SlewSetting);	// Restore the previous AF2 autoslew setting

out

/* Socket End Packet */


