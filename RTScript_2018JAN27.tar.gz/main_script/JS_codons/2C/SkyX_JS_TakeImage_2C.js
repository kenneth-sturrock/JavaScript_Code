/* Java Script */
/* Socket Start Packet */

//	
//	This JavaScript is meant to be sent to a second imaging camera of opportunity
//
//	Ken Sturrock 
//	January 13, 2018
//

var target = "$000"

ccdsoftCamera.Connect();

while (!ccdsoftCamera.State == 0)
//
// Diagnostic routine to make sure the camera is *really* ready
//
{
	sky6Web.Sleep (1000); 
}



ccdsoftCamera.Asynchronous = true;		// Don't wait around, we'll check back later.
ccdsoftCamera.AutoSaveOn = true;		// Keep the image
ccdsoftCamera.ImageReduction = 0;		// Don't do autodark, change this if you do want some other calibration (1=AD, 2=full)
ccdsoftCamera.Frame = 1;			// It's a light frame
ccdsoftCamera.Delay = 10;			// Pause 10 seconds to let the main camera get going.
ccdsoftCamera.Subframe = false;			// Not a subframe


if ( SelectedHardware.mountModel == "Telescope Mount Simulator")
//
// See if we are running the simulator which will let us "fake slew" 
// and properly name the images.
//
{
	sky6RASCOMTele.Connect();

	sky6RASCOMTele.Asynchronous = false;

	sky6StarChart.Find(target);	

	sky6ObjectInformation.Property(54); 				// Pull the RA value 
		var targetRA = sky6ObjectInformation.ObjInfoPropOut; 		// Stuff RA into variable 

	sky6ObjectInformation.Property(55); 				// Pull the DEC value 
		var targetDEC = sky6ObjectInformation.ObjInfoPropOut; 		// Stuff DEC into variable 

	sky6RASCOMTele.SlewToRaDec(targetRA, targetDEC, target); 	// Go to the RA & DEC
}


ccdsoftCamera.TakeImage();

ccdsoftCamera.ExposureTime;			// Report the exposure time

/* Socket End Packet */

