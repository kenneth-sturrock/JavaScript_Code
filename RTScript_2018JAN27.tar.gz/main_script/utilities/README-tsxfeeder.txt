These scripts require a program, called "tsxfeeder", that was written by Terry Friedrichson
at the "Bunker Ranch Observatory":

http://www.bunker-ranch.com/

Tsxfeeder is used to send JavaScript from a file to The SkyX by means of a TCP port.

In addition to sending the file, it can strip out comments & white space to keep the file 
under the four kilobyte limit and can also replace codes within the JavaScript code with
text supplied on the command line.

You can build it yourself from the enclosed sources or use the version that I compiled.

You can also use the pre-compiled versions for a few platforms that I had on-hand. These are located in my file library on the bisque site:

https://www.bisque.com/sc/members/ksturrock/files/default.aspx

Thanks for writing such a great utility, Terry.

